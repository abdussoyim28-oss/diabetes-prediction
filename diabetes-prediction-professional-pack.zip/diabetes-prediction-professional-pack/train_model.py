"""Train and evaluate a Logistic Regression diabetes classifier.

Expected input: diabetes.csv in the project root, with an Outcome target column.
This is an educational example, not a clinically validated tool.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "diabetes.csv"
ARTIFACTS_DIR = ROOT / "artifacts"

FEATURE_COLUMNS = [
    "Pregnancies",
    "Glucose",
    "BloodPressure",
    "SkinThickness",
    "Insulin",
    "BMI",
    "DiabetesPedigreeFunction",
    "Age",
]
TARGET_COLUMN = "Outcome"

# In this common dataset, zero is a placeholder for missingness in these
# measurements. Pregnancies and Outcome are not treated this way.
ZERO_AS_MISSING = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]


def load_dataset(path: Path = DATA_PATH) -> tuple[pd.DataFrame, pd.Series]:
    """Load the dataset and validate required columns and target values."""
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. Place diabetes.csv in the repository root."
        )

    frame = pd.read_csv(path)
    required = FEATURE_COLUMNS + [TARGET_COLUMN]
    missing = sorted(set(required) - set(frame.columns))
    if missing:
        raise ValueError(
            "Dataset is missing expected columns: "
            + ", ".join(missing)
            + ". Update FEATURE_COLUMNS/TARGET_COLUMN after inspecting your CSV."
        )

    frame = frame[required].copy()
    if frame.empty:
        raise ValueError("Dataset contains no rows.")
    frame[TARGET_COLUMN] = pd.to_numeric(frame[TARGET_COLUMN], errors="raise")
    labels = set(frame[TARGET_COLUMN].dropna().unique())
    if not labels.issubset({0, 1}) or frame[TARGET_COLUMN].isna().any():
        raise ValueError("Outcome must contain only non-missing binary values 0 and 1.")

    for column in FEATURE_COLUMNS:
        frame[column] = pd.to_numeric(frame[column], errors="raise")
    for column in ZERO_AS_MISSING:
        frame.loc[frame[column] == 0, column] = np.nan

    return frame[FEATURE_COLUMNS], frame[TARGET_COLUMN].astype(int)


def build_pipeline() -> Pipeline:
    """Create a pipeline so preprocessing is fitted on training data only."""
    return Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            (
                "classifier",
                LogisticRegression(max_iter=2000, class_weight=None, random_state=42),
            ),
        ]
    )


def evaluate_model(model: Pipeline, x_test: pd.DataFrame, y_test: pd.Series) -> dict[str, Any]:
    """Return common binary-classification metrics."""
    predictions = model.predict(x_test)
    return {
        "accuracy": float(accuracy_score(y_test, predictions)),
        "precision": float(precision_score(y_test, predictions, zero_division=0)),
        "recall": float(recall_score(y_test, predictions, zero_division=0)),
        "f1_score": float(f1_score(y_test, predictions, zero_division=0)),
        "confusion_matrix": confusion_matrix(y_test, predictions).tolist(),
        "classification_report": classification_report(
            y_test, predictions, zero_division=0, output_dict=True
        ),
    }


def main() -> None:
    x, y = load_dataset()
    if y.value_counts().min() < 2:
        raise ValueError("Each target class needs at least two rows for a stratified split.")

    x_train, x_test, y_train, y_test = train_test_split(
        x,
        y,
        test_size=0.2,
        random_state=42,
        stratify=y,
    )
    model = build_pipeline()
    model.fit(x_train, y_train)
    metrics = evaluate_model(model, x_test, y_test)

    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, ARTIFACTS_DIR / "diabetes_logistic_regression.joblib")
    with (ARTIFACTS_DIR / "metrics.json").open("w", encoding="utf-8") as file:
        json.dump(metrics, file, indent=2)

    print("Held-out test metrics (educational evaluation only)")
    print(f"Accuracy : {metrics['accuracy']:.3f}")
    print(f"Precision: {metrics['precision']:.3f}")
    print(f"Recall   : {metrics['recall']:.3f}")
    print(f"F1-score : {metrics['f1_score']:.3f}")
    print("Confusion matrix [ [TN, FP], [FN, TP] ]:")
    print(np.array(metrics["confusion_matrix"]))
    print("\nClassification report:")
    print(classification_report(y_test, model.predict(x_test), zero_division=0))
    print(f"\nSaved model to: {ARTIFACTS_DIR / 'diabetes_logistic_regression.joblib'}")
    print(f"Saved metrics to: {ARTIFACTS_DIR / 'metrics.json'}")


if __name__ == "__main__":
    main()
