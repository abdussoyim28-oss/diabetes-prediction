# Contributing

Thanks for your interest in improving this educational project.

## Before opening a change

1. Open an issue or describe the proposed change clearly.
2. Keep changes focused and explain the reason for them.
3. Do not add real patient information, secrets, credentials, or large generated model files.
4. Verify dataset provenance and applicable terms before redistributing data.
5. Run `pytest -q` and, when changing training code, run `python train_model.py` locally.
6. Do not report performance numbers unless they were reproduced from the documented workflow.

## Pull requests

Include a short summary, test results, and any limitations introduced by the change. Healthcare-related claims must remain cautious and evidence-based.
