import pandas as pd
import pytest

from train_model import FEATURE_COLUMNS, TARGET_COLUMN, build_pipeline, load_dataset


def test_build_pipeline_has_preprocessing_and_classifier():
    pipeline = build_pipeline()
    assert "imputer" in pipeline.named_steps
    assert "scaler" in pipeline.named_steps
    assert "classifier" in pipeline.named_steps


def test_load_dataset_rejects_missing_file(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_dataset(tmp_path / "missing.csv")


def test_load_dataset_validates_schema(tmp_path):
    path = tmp_path / "bad.csv"
    pd.DataFrame({"feature": [1, 2], TARGET_COLUMN: [0, 1]}).to_csv(path, index=False)
    with pytest.raises(ValueError, match="missing expected columns"):
        load_dataset(path)


def test_expected_schema_is_explicit():
    assert len(FEATURE_COLUMNS) == 8
    assert TARGET_COLUMN == "Outcome"
