# Diabetes Prediction Using Machine Learning

A reproducible machine-learning project that explores binary classification on a diabetes dataset using **Logistic Regression**.

> **Educational use only:** This project is not a medical device and must not be used to diagnose diabetes, make treatment decisions, or replace advice from a qualified healthcare professional.

## Project goals

- Explore a tabular health dataset.
- Build a repeatable preprocessing and training pipeline.
- Evaluate a classifier using multiple metrics rather than accuracy alone.
- Make the workflow easier to reproduce and review.

## Current repository contents

The original repository includes:

- `Diabetes_prediction_system.ipynb` — exploratory notebook.
- `diabetes.csv` — dataset file.
- `README.md` — project documentation.

The professionalization pack adds a standalone training script, dependency list, tests, and CI configuration. Copy these files into the repository root while preserving your existing notebook and dataset.

## Technology stack

- Python
- pandas and NumPy
- scikit-learn
- joblib
- pytest

## Dataset expectations

The training script expects `diabetes.csv` in the repository root. It is designed for the commonly used Pima Indians Diabetes-style schema, with these columns:

`Pregnancies`, `Glucose`, `BloodPressure`, `SkinThickness`, `Insulin`, `BMI`, `DiabetesPedigreeFunction`, `Age`, and `Outcome`.

`Outcome` is the binary target column (0 or 1). If your CSV uses different column names, update `FEATURE_COLUMNS` and `TARGET_COLUMN` in `train_model.py` after checking the actual file.

Before publishing the dataset, verify its source, usage terms, and attribution requirements. Do not imply that it represents all populations.

## Setup

Python 3.10 or 3.11 is recommended.

### 1. Clone the repository

```bash
git clone https://github.com/abdussoyim28-oss/diabetes-prediction.git
cd diabetes-prediction
```

### 2. Create and activate a virtual environment

Windows PowerShell:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Train and evaluate

```bash
python train_model.py
```

The script validates the expected columns, splits the data using stratification, trains a preprocessing-plus-Logistic-Regression pipeline, prints evaluation metrics, and saves generated artifacts under `artifacts/`.

Generated model files and evaluation output should be reviewed before committing. The `.gitignore` excludes generated artifacts by default.

### 5. Run tests

```bash
pytest -q
```

## Methodology

1. Load the CSV and validate its schema.
2. Replace common placeholder zeros in selected clinical measurement columns with missing values.
3. Split the data into training and test subsets with stratification.
4. Fit imputation, feature scaling, and Logistic Regression inside a scikit-learn pipeline. Fitting preprocessing only on the training subset helps prevent test-set leakage.
5. Evaluate predictions on the held-out test subset.

The script reports accuracy, precision, recall, F1-score, a confusion matrix, and a classification report. Results depend on the dataset, split, and software versions. Do not copy metrics into a resume or README until you have run the script and confirmed the output.

## Repository structure

```text
diabetes-prediction/
├── .github/
│   └── workflows/
│       └── tests.yml
├── tests/
│   └── test_train_model.py
├── Diabetes_prediction_system.ipynb
├── diabetes.csv
├── train_model.py
├── requirements.txt
├── .gitignore
├── CONTRIBUTING.md
└── README.md
```

## Limitations and responsible use

- This is a learning project, not a clinically validated prediction system.
- Performance on one dataset does not establish generalization to other populations or clinical settings.
- Accuracy alone is insufficient for evaluating a healthcare-related classifier; false negatives, false positives, calibration, and external validation matter.
- Dataset provenance, licensing, representativeness, and consent context should be checked and documented.
- Do not enter real patient data into an unreviewed demo or deploy the model for clinical decisions.

## Roadmap

- [ ] Re-run the notebook and verify every metric in this README.
- [ ] Add a dataset citation and licensing/usage notes.
- [ ] Add a confusion-matrix plot and ROC-AUC if appropriate.
- [ ] Compare Logistic Regression with a justified baseline model using the same split.
- [ ] Add data validation and more edge-case tests.
- [ ] If building a web interface, keep model inference separate from notebook exploration and add input validation.

## Author

**Abdus Soyim** — Machine Learning project.

If you use or adapt this project, please preserve the dataset's required attribution and terms.
