# How to apply this professionalization pack

This pack contains add-on files; it does not replace your original notebook or dataset.

1. Download and extract the ZIP.
2. Copy the files and folders into the root of your existing `diabetes-prediction` repository.
3. Keep `Diabetes_prediction_system.ipynb` and `diabetes.csv`.
4. Check that the CSV has the expected columns listed in `README.md`. If not, update the constants in `train_model.py` to match the real column names.
5. Create a virtual environment and install `requirements.txt`.
6. Run `python train_model.py`, then `pytest -q`.
7. Fix any errors and review the actual metrics before writing them into your resume.
8. Commit and push the changes to GitHub.

Suggested commit message:
`chore: improve project structure, reproducibility, and tests`

Do not commit your virtual environment, credentials, generated model artifacts, or patient-identifiable data. This pack has not been run against your repository's actual CSV in this environment, so the schema and execution steps must be verified locally before publishing.
